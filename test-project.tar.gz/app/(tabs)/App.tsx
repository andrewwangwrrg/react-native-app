// App.tsx
import "expo-router/entry";

